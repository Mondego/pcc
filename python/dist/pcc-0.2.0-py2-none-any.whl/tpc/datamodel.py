from __future__ import absolute_import

from rtypes.pcc.attributes import dimension, primarykey, count, namespace
from rtypes.pcc.types.set import pcc_set
from rtypes.pcc.types.subset import subset
from rtypes.pcc.types.impure import impure
from rtypes.pcc.types.parameter import parameter, ParameterMode
from rtypes.pcc.types.join import join
from rtypes.pcc.types.projection import projection
from rtypes.pcc import this


class PART(object):
    @primarykey(long)
    def P_PARTKEY(self):
        return self._p_partkey

    @P_PARTKEY.setter
    def P_PARTKEY(self, v):
        self._p_partkey = v

    @dimension(str)
    def P_NAME(self):
        return self._p_name

    @P_NAME.setter
    def P_NAME(self, v):
        self._p_name = v

    @dimension(str)
    def P_MFGR(self):
        return self._p_mfgr

    @P_MFGR.setter
    def P_MFGR(self, v):
        self._p_mfgr = v

    @dimension(str)
    def P_BRAND(self):
        return self._p_brand

    @P_BRAND.setter
    def P_BRAND(self, v):
        self._p_brand = v

    @dimension(str)
    def P_TYPE(self):
        return self._p_type

    @P_TYPE.setter
    def P_TYPE(self, v):
        self._p_type = v

    @dimension(int)
    def P_SIZE(self):
        return self._p_size

    @P_SIZE.setter
    def P_SIZE(self, v):
        self._p_size = v

    @dimension(str)
    def P_CONTAINER(self):
        return self._p_container

    @P_CONTAINER.setter
    def P_CONTAINER(self, v):
        self._p_container = v

    @dimension(str)
    def P_NAME(self):
        return self._p_name

    @P_NAME.setter
    def P_NAME(self, v):
        self._p_name = v

