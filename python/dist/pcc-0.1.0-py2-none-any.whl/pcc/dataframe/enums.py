class ObjectType(object):
    UnknownType = 0
    PCCBase = 1
    ISA = 2
    Subset = 3
    Join = 4
    Projection = 5
    Union = 6
    Param = 7
    Impure = 8

